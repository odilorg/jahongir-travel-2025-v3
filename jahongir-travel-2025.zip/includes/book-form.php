
<div class="summary entry-summary description_single">
							<div class="affix-sidebar">
								<div class="entry-content-tour">
									<p class="price">
										<span class="text">	via WhatsApp <a href="https://wa.me/998940771303">+998 94 077 13 03</a> </span><span class="travel_tour-Price-amount amount">for booking or use form below</span>
									</p>
									
									<div class="clear"></div>
									<div class="booking">
										<div class="">
											<div class="form-block__title">
												<h4>Book the tour </h4>
												
											</div>
                                            
											<form action="" method="post" id="tourBookingForm" >
												<div class="">
													<input name="first_name" value="" placeholder="First name" type="text" required>
												</div>
												<div class="">
													<input name="last_name" value="" placeholder="Last name" type="text" required>
												</div>
												<div class="">
													<input name="email" value="" placeholder="Email" type="email" required>
												</div>
													<div class="">
													<input name="phone" value="" placeholder="Whatsapp phone w/country code" type="text"  required>
												</div>
												<div class="">
													<input name="hotel_to_pickup" value="" placeholder="Name of the hotel to pick up" type="text" required>
												</div>
												<div class="">
													<input type="text" id="date" name="departure_date" placeholder="Departure Date" class="hasDatepicker" required >
												</div>
												<div class="from-group">
													<div class="total_price_arrow">
														<div class="st_adults_children">
															<span class="label">Adults</span>
															<div class="input-number-ticket">
																<input type="number" name="number_adults" min ="0" max="10"   required>
															</div>
															
														</div>
														<div class="st_adults_children">
															<span class="label">Children</span>
															<div class="input-number-ticket">
																<input type="number" name="number_children" min="0" max="10" >
																
															</div>
															
														</div>
														
														
													</div>
												</div>
											
												<div class="spinner">
													<div class="rect1"></div>
													<div class="rect2"></div>
													<div class="rect3"></div>
													<div class="rect4"></div>
													<div class="rect5"></div>
												</div>
                                                <div class="g-recaptcha" data-sitekey="6Ld3L10aAAAAAPAKJ-94qhAv-m01T2fYZtX73nEO"></div>
												<input class="btn-booking btn" name='submit' value="Book now" type="submit">
                                                
												
								